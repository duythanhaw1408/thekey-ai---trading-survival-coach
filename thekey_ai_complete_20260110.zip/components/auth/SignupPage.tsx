/**
 * THEKEY AI - Signup Page
 * Email/Password registration with email verification notice
 */

import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { AuthLayout } from './AuthLayout';
import { useAuth } from '../../contexts/AuthContext';

interface SignupPageProps {
    onSwitchToLogin: () => void;
}

export const SignupPage: React.FC<SignupPageProps> = ({ onSwitchToLogin }) => {
    const { signup, loginWithGoogle, isLoading } = useAuth();
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [agreedToTerms, setAgreedToTerms] = useState(false);
    const [error, setError] = useState('');
    const [success, setSuccess] = useState(false);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setError('');

        if (!email || !password || !confirmPassword) {
            setError('Vui lòng điền đầy đủ thông tin');
            return;
        }

        if (password.length < 8) {
            setError('Mật khẩu phải có ít nhất 8 ký tự');
            return;
        }

        if (password !== confirmPassword) {
            setError('Mật khẩu xác nhận không khớp');
            return;
        }

        if (!agreedToTerms) {
            setError('Vui lòng đồng ý với điều khoản sử dụng');
            return;
        }

        try {
            await signup(email, password);
            setSuccess(true);
        } catch (err) {
            setError(err instanceof Error ? err.message : 'Đăng ký thất bại');
        }
    };

    const handleGoogleSignup = async () => {
        try {
            await loginWithGoogle();
        } catch (err) {
            setError('Google login không khả dụng');
        }
    };

    if (success) {
        return (
            <AuthLayout title="Xác nhận Email" subtitle="Kiểm tra hộp thư của bạn">
                <motion.div
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="text-center py-8"
                >
                    <div className="w-16 h-16 bg-green-500/20 rounded-full flex items-center justify-center mx-auto mb-4">
                        <svg className="w-8 h-8 text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                        </svg>
                    </div>
                    <h3 className="text-white text-lg font-semibold mb-2">Đăng ký thành công!</h3>
                    <p className="text-gray-400 mb-6">
                        Chúng tôi đã gửi email xác nhận đến <span className="text-cyan-400">{email}</span>.
                        Vui lòng kiểm tra và xác nhận để kích hoạt tài khoản Pro.
                    </p>
                    <button
                        onClick={onSwitchToLogin}
                        className="text-cyan-400 hover:text-cyan-300 font-medium transition-colors"
                    >
                        Đăng nhập ngay
                    </button>
                </motion.div>
            </AuthLayout>
        );
    }

    return (
        <AuthLayout title="Tạo tài khoản" subtitle="Bắt đầu hành trình trading của bạn">
            <form onSubmit={handleSubmit} className="space-y-4">
                {/* Error Message */}
                {error && (
                    <motion.div
                        initial={{ opacity: 0, y: -10 }}
                        animate={{ opacity: 1, y: 0 }}
                        className="p-3 bg-red-500/10 border border-red-500/30 rounded-lg text-red-400 text-sm text-center"
                    >
                        {error}
                    </motion.div>
                )}

                {/* Email Input */}
                <div>
                    <label className="block text-gray-400 text-sm mb-2">Email</label>
                    <input
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="your@email.com"
                        className="w-full px-4 py-3 bg-gray-900/50 border border-gray-700 rounded-xl text-white placeholder-gray-500 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 transition-all"
                        disabled={isLoading}
                    />
                </div>

                {/* Password Input */}
                <div>
                    <label className="block text-gray-400 text-sm mb-2">Mật khẩu</label>
                    <input
                        type="password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        placeholder="Ít nhất 8 ký tự"
                        className="w-full px-4 py-3 bg-gray-900/50 border border-gray-700 rounded-xl text-white placeholder-gray-500 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 transition-all"
                        disabled={isLoading}
                    />
                    {/* Password Strength Indicator */}
                    {password && (
                        <div className="mt-2 space-y-2">
                            {/* Strength Bar */}
                            <div className="flex gap-1">
                                {[1, 2, 3, 4].map((i) => {
                                    const hasUpper = /[A-Z]/.test(password);
                                    const hasLower = /[a-z]/.test(password);
                                    const hasNumber = /\d/.test(password);
                                    const hasLength = password.length >= 8;
                                    const score = [hasLength, hasUpper, hasLower, hasNumber].filter(Boolean).length;

                                    let color = 'bg-gray-700';
                                    if (score >= i) {
                                        if (score <= 2) color = 'bg-red-500';
                                        else if (score === 3) color = 'bg-yellow-500';
                                        else color = 'bg-green-500';
                                    }
                                    return <div key={i} className={`h-1 flex-1 rounded-full transition-all ${color}`} />;
                                })}
                            </div>
                            {/* Requirements Checklist */}
                            <div className="text-xs space-y-1">
                                <div className={password.length >= 8 ? 'text-green-400' : 'text-gray-500'}>
                                    {password.length >= 8 ? '✓' : '○'} Ít nhất 8 ký tự
                                </div>
                                <div className={/[A-Z]/.test(password) ? 'text-green-400' : 'text-gray-500'}>
                                    {/[A-Z]/.test(password) ? '✓' : '○'} Có chữ hoa (A-Z)
                                </div>
                                <div className={/[a-z]/.test(password) ? 'text-green-400' : 'text-gray-500'}>
                                    {/[a-z]/.test(password) ? '✓' : '○'} Có chữ thường (a-z)
                                </div>
                                <div className={/\d/.test(password) ? 'text-green-400' : 'text-gray-500'}>
                                    {/\d/.test(password) ? '✓' : '○'} Có số (0-9)
                                </div>
                            </div>
                        </div>
                    )}
                </div>

                {/* Confirm Password Input */}
                <div>
                    <label className="block text-gray-400 text-sm mb-2">Xác nhận mật khẩu</label>
                    <input
                        type="password"
                        value={confirmPassword}
                        onChange={(e) => setConfirmPassword(e.target.value)}
                        placeholder="Nhập lại mật khẩu"
                        className="w-full px-4 py-3 bg-gray-900/50 border border-gray-700 rounded-xl text-white placeholder-gray-500 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 transition-all"
                        disabled={isLoading}
                    />
                </div>

                {/* Terms Checkbox */}
                <label className="flex items-start gap-3 text-gray-400 text-sm cursor-pointer">
                    <input
                        type="checkbox"
                        checked={agreedToTerms}
                        onChange={(e) => setAgreedToTerms(e.target.checked)}
                        className="w-4 h-4 mt-0.5 rounded border-gray-600 bg-gray-900 text-cyan-500 focus:ring-cyan-500"
                    />
                    <span>
                        Tôi đồng ý với{' '}
                        <a href="#" className="text-cyan-400 hover:text-cyan-300">Điều khoản sử dụng</a>
                        {' '}và{' '}
                        <a href="#" className="text-cyan-400 hover:text-cyan-300">Chính sách bảo mật</a>
                    </span>
                </label>

                {/* Pro Notice */}
                <div className="p-3 bg-cyan-500/10 border border-cyan-500/30 rounded-lg text-cyan-400 text-sm">
                    💡 Xác nhận email để mở khóa tính năng <span className="font-semibold">Pro</span>: AI insights nâng cao, reports chi tiết, và nhiều hơn nữa!
                </div>

                {/* Submit Button */}
                <motion.button
                    type="submit"
                    disabled={isLoading}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    className="w-full py-3 bg-gradient-to-r from-cyan-500 to-purple-600 text-white font-semibold rounded-xl shadow-lg shadow-cyan-500/25 hover:shadow-cyan-500/40 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                >
                    {isLoading ? 'Đang tạo tài khoản...' : 'Tạo tài khoản'}
                </motion.button>

                {/* Divider */}
                <div className="relative my-6">
                    <div className="absolute inset-0 flex items-center">
                        <div className="w-full border-t border-gray-700"></div>
                    </div>
                    <div className="relative flex justify-center text-sm">
                        <span className="px-4 bg-gray-800/50 text-gray-500">hoặc</span>
                    </div>
                </div>

                {/* Google Signup */}
                <motion.button
                    type="button"
                    onClick={handleGoogleSignup}
                    disabled={isLoading}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    className="w-full py-3 bg-white text-gray-900 font-semibold rounded-xl flex items-center justify-center gap-3 hover:bg-gray-100 transition-all disabled:opacity-50"
                >
                    <svg className="w-5 h-5" viewBox="0 0 24 24">
                        <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                        <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                        <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" />
                        <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" />
                    </svg>
                    Đăng ký với Google
                </motion.button>

                {/* Switch to Login */}
                <p className="text-center text-gray-400 mt-6">
                    Đã có tài khoản?{' '}
                    <button
                        type="button"
                        onClick={onSwitchToLogin}
                        className="text-cyan-400 hover:text-cyan-300 font-medium transition-colors"
                    >
                        Đăng nhập
                    </button>
                </p>
            </form>
        </AuthLayout>
    );
};
