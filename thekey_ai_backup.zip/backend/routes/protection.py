from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from pydantic import BaseModel
from typing import Optional, Dict
from services.protection.revenge_blocker import RevengeTradePrevention
from services.protection.size_guardian import PositionSizeGuardian
from services.ai.gemini_client import gemini_client
from services.auth.dependencies import get_current_user
from models import get_db, User, Trade

router = APIRouter(prefix="/api/protection", tags=["protection"])

class TradeIntent(BaseModel):
    symbol: str
    side: str
    size: float
    entry_price: float
    account_balance: float

@router.post("/check-trade")
async def check_trade(data: Dict, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    """
    Check if a proposed trade violates any protection rules, including AI evaluation.
    """
    # Extract data (matching frontend format)
    trade = data.get("trade", {})
    stats = data.get("stats", {})
    trade_history = data.get("tradeHistory", [])
    settings = data.get("settings", {})
    active_pattern = data.get("activePattern")
    market_analysis = data.get("marketAnalysis")

    # 1. Basic Rule Checks (Revenge & Size)
    # Fetch recent trades for this user
    recent_trades = db.query(Trade).filter(Trade.user_id == user.id).order_by(Trade.entry_time.desc()).limit(10).all()
    
    # Use user-specific protection settings
    cooldown = user.cooldown_minutes or 30
    loss_limit = user.consecutive_loss_limit or 2
    
    revenge_blocker = RevengeTradePrevention(str(user.id), cooldown_minutes=cooldown, consecutive_loss_limit=loss_limit)
    revenge_result = await revenge_blocker.check_can_trade(recent_trades)
    
    # 2. AI Evaluation
    ai_context = {
        "account_balance": user.account_balance,
        "trade": trade,
        "stats": stats,
        "trade_history": trade_history,
        "settings": settings,
        "active_pattern": active_pattern,
        "market_danger": market_analysis.get("danger_level") if market_analysis else "Unknown"
    }
    
    ai_feedback = await gemini_client.get_trade_evaluation(ai_context)
    
    # 3. Decision Integration
    # If basic rules block, they take precedence
    if not revenge_result.get("allowed", True):
        return {
            "decision": "BLOCK",
            "reason": revenge_result.get("message"),
            "cooldown": 1800,
            "recommended_size": 0
        }
    
    # Otherwise return AI feedback (which integrates other rules conceptually)
    return ai_feedback

@router.get("/market-context")
async def get_market_context(user: User = Depends(get_current_user)):
    """Get AI-generated market danger analysis."""
    analysis = await gemini_client.generate_market_analysis()
    return analysis

@router.post("/analyze-trade")
async def analyze_trade(trade_data: Dict, user: User = Depends(get_current_user)):
    """Analyze a specific trade."""
    user_stats = {
        "survival_days": user.survival_score, # Using survival_score as proxy
        "discipline_score": user.survival_score # Placeholder
    }
    analysis = await gemini_client.analyze_trade(trade_data, user_stats)
    return analysis

@router.post("/emotional-tilt")
async def emotional_tilt(data: Dict, user: User = Depends(get_current_user)):
    """Detect emotional tilt and intervention message."""
    stats = data.get("stats", {})
    history = data.get("history", [])
    result = await gemini_client.detect_emotional_tilt(stats, history)
    return result
