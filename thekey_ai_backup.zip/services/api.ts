// frontend/src/services/api.ts

// FIX: Removed /api suffix - backend routes don't have that prefix
const API_BASE_URL = import.meta.env?.VITE_API_URL || 'http://localhost:8000';

export interface TradeIntent {
    symbol: string;
    side: 'BUY' | 'SELL';
    size: number;
    entry_price: number;
    account_balance: number;
}

/**
 * Centralized Request Helper
 * Automatically handles Auth Headers, JSON parsing, token refresh on 401, and basic errors.
 */
const request = async <T = any>(endpoint: string, options: RequestInit = {}, _isRetry = false): Promise<T> => {
    const token = localStorage.getItem('thekey_access_token');
    const headers = {
        'Content-Type': 'application/json',
        ...(token ? { 'Authorization': `Bearer ${token}` } : {}),
        ...options.headers,
    };

    const response = await fetch(`${API_BASE_URL}${endpoint}`, {
        ...options,
        headers,
    });

    // Handle 401 with token refresh (only retry once)
    if (response.status === 401 && !_isRetry) {
        console.log('[API] Got 401, attempting token refresh...');
        const refreshToken = localStorage.getItem('thekey_refresh_token');
        if (refreshToken) {
            try {
                const refreshResponse = await fetch(`${API_BASE_URL}/auth/refresh?refresh_token=${encodeURIComponent(refreshToken)}`, {
                    method: 'POST'
                });
                if (refreshResponse.ok) {
                    const data = await refreshResponse.json();
                    localStorage.setItem('thekey_access_token', data.access_token);
                    console.log('[API] Token refreshed successfully, retrying request...');
                    return request<T>(endpoint, options, true); // Retry with new token
                }
            } catch (e) {
                console.error('[API] Token refresh failed:', e);
            }
        }
        // Refresh failed - redirect to login or handle gracefully
        console.warn('[API] Token refresh failed, user needs to re-authenticate');
    }

    if (!response.ok) {
        const error = await response.json().catch(() => ({ detail: 'Unknown error occurred' }));
        throw new Error(error.detail || `Request failed with status ${response.status}`);
    }

    return response.json();
};

export const api = {
    // Protection (routes have /api prefix)
    getMarketContext: () => request('/api/protection/market-context'),
    checkTrade: (data: any) => request('/api/protection/check-trade', {
        method: 'POST',
        body: JSON.stringify(data)
    }),

    getTraderArchetype: (data: any) => request('/api/learning/archetype', {
        method: 'POST',
        body: JSON.stringify(data)
    }),
    // Reflection
    getCheckinQuestions: () => request('/api/reflection/checkin/questions'),
    submitCheckin: (answers: any[]) => request('/api/reflection/checkin/submit', {
        method: 'POST',
        body: JSON.stringify({ answers }),
    }),

    // Trades
    recordTrade: (trade: any) => request('/api/trades/', {
        method: 'POST',
        body: JSON.stringify(trade),
    }),
    getTradeHistory: () => request('/api/trades/'),  // No userId needed - backend uses auth token

    // Progress
    getProgressSummary: () => request('/api/progress/summary'),

    // Coach / AI Chat
    getInitialMessage: async () => {
        const data = await request('/api/reflection/initial-message');
        return data.text;
    },
    getChatResponse: (message: string, history: any[], mode: 'COACH' | 'PROTECTOR' = 'COACH') =>
        request('/api/reflection/chat', {
            method: 'POST',
            body: JSON.stringify({ message, history, mode }),
        }),

    getPostTradeAnalysis: (trade: any) => request('/api/protection/analyze-trade', {
        method: 'POST',
        body: JSON.stringify(trade),
    }),

    getEmotionalTiltIntervention: (stats: any, history: any[]) => request('/api/protection/emotional-tilt', {
        method: 'POST',
        body: JSON.stringify({ stats, history }),
    }),

    getWeeklyGoals: (history: any[], stats: any, checkinHistory: any[]) => request('/api/progress/weekly-goals', {
        method: 'POST',
        body: JSON.stringify({ history, stats, checkinHistory }),
    }),

    getWeeklyReport: (history: any[]) => request('/api/progress/weekly-report', {
        method: 'POST',
        body: JSON.stringify({ history }),
    }),

    // User Settings
    getCurrentUser: () => request('/auth/me'),
    updateSettings: (settings: any) => request('/auth/settings', {
        method: 'PUT',
        body: JSON.stringify(settings)
    }),

    // Learning Engine Sync
    recordTradeCorrelation: (data: any) => request('/api/learning/correlations/record', {
        method: 'POST',
        body: JSON.stringify(data)
    }),
    recordShadowPattern: (data: any) => request('/api/learning/shadow-patterns/record', {
        method: 'POST',
        body: JSON.stringify(data)
    }),
    recordCrisisRecovery: (data: any) => request('/api/learning/crisis-recovery/record', {
        method: 'POST',
        body: JSON.stringify(data)
    }),
    getLearningInsights: () => request('/api/learning/insights'),
    getLearningStats: () => request('/api/learning/stats')
};
